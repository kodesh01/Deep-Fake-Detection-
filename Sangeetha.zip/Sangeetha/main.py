import requests

def check_url_virustotal(api_key, url):
    endpoint = "https://www.virustotal.com/vtapi/v2/url/report"
    params = {'apikey': api_key, 'resource': url}
    response = requests.get(endpoint, params=params)
    result = response.json()

    if result["response_code"] == 1:
        if result["positives"] > 0:
            return f"Unsafe URL detected! {result['positives']} sources flagged this URL."
        else:
            return "The URL is safe."
    else:
        return "URL not found in VirusTotal database."

# Example usage
api_key = "2f3c0a357ee11857bcd5fad616d0e4a0dac8572c22b20c7584ce2832cee1c2d8"
url_to_check = "http://example.com"
result = check_url_virustotal(api_key, url_to_check)
print(result)

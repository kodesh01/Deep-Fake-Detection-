from flask import Flask, render_template, request
import requests

app = Flask(__name__)

def check_url_virustotal(api_key, url):
    endpoint = "https://www.virustotal.com/vtapi/v2/url/report"
    params = {'apikey': api_key, 'resource': url}

    response = requests.get(endpoint, params=params)
    result = response.json()

    if result["response_code"] == 1:
        if result["positives"] > 0:
            return f"Unsafe URL detected! {result['positives']} sources flagged this URL."
        else:
            return "The URL is safe."
    else:
        return "URL not found in VirusTotal database."
@app.route('/', methods=['GET', 'POST'])
def index():
    result = None
    if request.method == 'POST':
        url_to_check = request.form['url']
        api_key = "2f3c0a357ee11857bcd5fad616d0e4a0dac8572c22b20c7584ce2832cee1c2d8"
        result = check_url_virustotal(api_key, url_to_check)
    return render_template('index.html', result=result)

if __name__ == '__main__':
    app.run(debug=True)
